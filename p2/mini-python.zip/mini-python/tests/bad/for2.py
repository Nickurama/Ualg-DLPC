for x in []:
    print(x)
print(x)
