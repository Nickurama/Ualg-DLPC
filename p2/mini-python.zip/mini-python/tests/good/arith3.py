print(17//2)
