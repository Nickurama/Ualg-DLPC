print(42)
