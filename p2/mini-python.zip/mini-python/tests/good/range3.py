l = list(range(7))
for x in l:
    print(x)





