
open Ast
open Format

(* Exceção levantada para sinalizar um erro durante a interpretação. *)
exception Error of string
let error s = raise (Error s)

(* Os valores de Mini-Python

   - uma diferença notável em relação ao Python: aqui utiliza-se o tipo int,
   enquanto em Python os inteiros têm precisão arbitrária; poder-se-ia usar
   o módulo Big_int de OCaml, mas opta-se aqui pela simplicidade;

   - aquilo a que o Python chama lista é, na realidade, um array redimensionável;
   no fragmento considerado aqui, não há possibilidade de alterar o seu comprimento,
   portanto um simples array de OCaml é suficiente.
*)
type value =
  | Vnone
  | Vbool of bool
  | Vint of int
  | Vstring of string
  | Vlist of value array

(* Exibição de um valor na saída padrão. *)
let rec print_value = function
  | Vnone -> printf "None"
  | Vbool true -> printf "True"
  | Vbool false -> printf "False"
  | Vint n -> printf "%d" n
  | Vstring s -> printf "%s" s
  | Vlist a ->
    let n = Array.length a in
    printf "[";
    for i = 0 to n-1 do print_value a.(i); if i < n-1 then printf ", " done;
    printf "]"

(* Interpretação booleana de um valor

Em Python, qualquer valor pode ser usado como um valor booleano: None, 
a lista vazia, a cadeia de caracteres vazia e o inteiro 0 são considerados 
como False, e qualquer outro valor é considerado como True. *)

let is_false (v: value) = assert false (* por completar (questão 2) *)

let is_true (v: value) = assert false (*  por completar (questão 2) *)

(* As funções aqui são apenas globais. *)

let functions = (Hashtbl.create 16 : (string, ident list * stmt) Hashtbl.t)

(* A instrução return do Python é interpretada com recurso a uma exceção. *)

exception Return of value

(* As variáveis locais (parâmetros de funções e variáveis introduzidas por 
atribuições) são armazenadas numa tabela de dispersão (hash table) passada 
como argumento às funções seguintes sob o nome ctx. *)

type ctx = (string, value) Hashtbl.t

(* Interpretação de uma expressão (devolve um valor). *)

let rec expr (ctx: ctx) = function
  | Ecst Cnone ->
      Vnone
  | Ecst (Cstring s) ->
      Vstring s
  (* arithmética *)
  | Ecst (Cint n) ->
      assert false (* por completar (questão 1) *)
  | Ebinop (Badd | Bsub | Bmul | Bdiv | Bmod |
            Beq | Bneq | Blt | Ble | Bgt | Bge as op, e1, e2) ->
      let v1 = expr ctx e1 in
      let v2 = expr ctx e2 in
      begin match op, v1, v2 with
        | Badd, Vint n1, Vint n2 -> assert false (*  por completar (questão 1) *)
        | Bsub, Vint n1, Vint n2 -> assert false (*  por completar (questão 1) *)
        | Bmul, Vint n1, Vint n2 -> assert false (*  por completar (questão 1) *)
        | Bdiv, Vint n1, Vint n2 -> assert false (*  por completar (questão 1) *)
        | Bmod, Vint n1, Vint n2 -> assert false (*  por completar (questão 1) *)
        | Beq, _, _  -> assert false (*  por completar (questão 2) *)
        | Bneq, _, _ -> assert false (*  por completar (questão 2) *)
        | Blt, _, _  -> assert false (*  por completar (questão 2) *)
        | Ble, _, _  -> assert false (*  por completar (questão 2) *)
        | Bgt, _, _  -> assert false (*  por completar (questão 2) *)
        | Bge, _, _  -> assert false (*  por completar (questão 2) *)
        | Badd, Vstring s1, Vstring s2 ->
            assert false (*  por completar (questão 3) *)
        | Badd, Vlist l1, Vlist l2 ->
            assert false (*  por completar (questão 5) *)
        | _ -> error "unsupported operand types"
      end
  | Eunop (Uneg, e1) ->
      assert false (*  por completar (questão 1) *)
  (* booleanos *)
  | Ecst (Cbool b) ->
      assert false (*  por completar (questão 2) *)
  | Ebinop (Band, e1, e2) ->
      assert false (*  por completar (questão 2) *)
  | Ebinop (Bor, e1, e2) ->
      assert false (*  por completar (questão 2) *)
  | Eunop (Unot, e1) ->
      assert false (*  por completar (questão 2) *)
  | Eident id ->
      assert false (*  por completar (questão 3) *)
  (* chamada de função *)
  | Ecall ("len", [e1]) ->
      assert false (*  por completar (questão 5) *)
  | Ecall ("list", [Ecall ("range", [e1])]) ->
      assert false (*  por completar (questão 5) *)
  | Ecall (f, el) ->
      assert false (*  por completar (questão 4) *)
  | Elist el ->
      assert false (*  por completar (questão 4) *)
  | Eget (e1, e2) ->
      assert false (*  por completar (questão 5) *)

(* Interpretação de uma instrução; não devolve nenhum valor. *)

and stmt (ctx: ctx) = function
  | Seval e ->
      ignore (expr ctx e)
  | Sprint e ->
      print_value (expr ctx e); printf "@."
  | Sblock bl ->
      block ctx bl
  | Sif (e, s1, s2) ->
      assert false (*  por completar (questão 2) *)
  | Sassign (id, e1) ->
      assert false (*  por completar (questão 3) *)
  | Sreturn e ->
      assert false (*  por completar (questão 4) *)
  | Sfor (x, e, s) ->
      assert false (*  por completar (questão 5) *)
  | Sset (e1, e2, e3) ->
      assert false (*  por completar (questão 5) *)

(* Interpretação de um bloco, isto é, de uma sequência de instruções. *)

and block (ctx: ctx) = function
  | [] -> ()
  | s :: sl -> stmt ctx s; block ctx sl

(* Interpretação de um ficheiro
- dl é uma lista de definições de funções (ver Ast.def)
- s é uma instrução, que representa as instruções globais.
 *)

let file ((dl: def list), (s: stmt)) =
  (*  por completar (questão 4) *)
  stmt (Hashtbl.create 16) s



